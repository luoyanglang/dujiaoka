<?php

namespace Plugins\TokenPayPayment;

use App\Exceptions\RuleValidationException;
use App\Http\Controllers\PayController;
use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Request;

class TokenPayController extends PayController
{
    public function gateway(string $payway, string $orderSN)
    {
        try {
            // 加载网关
            $this->loadGateWay($orderSN, $payway);
            
            // 构造请求参数
            $parameter = [
                "ActualAmount" => (float)$this->order->actual_price,
                "OutOrderId" => $this->order->order_sn, 
                "OrderUserKey" => $this->order->email, 
                "Currency" => $this->payGateway->merchant_id,
                'RedirectUrl' => route('tokenpay-return', ['order_id' => $this->order->order_sn]),
                'NotifyUrl' => url($this->payGateway->pay_handleroute . '/notify_url'),
            ];
            
            $parameter['Signature'] = $this->verifySign($parameter, $this->payGateway->merchant_key);
            
            $client = new Client([
                'headers' => ['Content-Type' => 'application/json']
            ]);
            
            $response = $client->post($this->payGateway->merchant_pem . '/CreateOrder', [
                'body' => json_encode($parameter)
            ]);
            
            $body = json_decode($response->getBody()->getContents(), true);
            
            if (!isset($body['success']) || $body['success'] != true) {
                return $this->err(__('dujiaoka.prompt.abnormal_payment_channel') . $body['message']);
            }
            
            return redirect()->away($body['data']);
            
        } catch (RuleValidationException $exception) {
            return $this->err($exception->getMessage());
        } catch (GuzzleException $exception) {
            return $this->err($exception->getMessage());
        }
    }

    private function verifySign(array $parameter, string $signKey)
    {
        ksort($parameter);
        reset($parameter);
        
        $sign = '';
        foreach ($parameter as $key => $val) {
            if ($key != 'Signature') {
                if ($sign != '') {
                    $sign .= "&";
                }
                $sign .= "$key=$val";
            }
        }
        
        return md5($sign . $signKey);
    }

    public function notifyUrl(Request $request)
    {
        $data = $request->all();
        $order = $this->orderService->detailOrderSN($data['OutOrderId']);
        
        if (!$order) {
            return 'fail';
        }
        
        $payGateway = $this->payService->detail($order->pay_id);
        
        if (!$payGateway) {
            return 'fail';
        }
        
        if ($payGateway->pay_handleroute != 'pay/tokenpay') {
            return 'fail';
        }
        
        // 验证签名
        $signature = $this->verifySign($data, $payGateway->merchant_key);
        
        if ($data['Signature'] != $signature) {
            return 'fail';
        }
        
        // 完成订单
        $this->orderProcessService->completedOrder(
            $data['OutOrderId'], 
            $data['ActualAmount'], 
            $data['Id']
        );
        
        return 'ok';
    }

    public function returnUrl(Request $request)
    {
        $oid = $request->get('order_id');
        sleep(2); // 等待异步通知
        return redirect(url('detail-order-sn', ['orderSN' => $oid]));
    }
}
