<?php

/**
 * TokenPay 支付插件 - 卸载脚本
 */

use Illuminate\Support\Facades\DB;

return function() {
    try {
        // 删除支付方式记录
        DB::table('pays')->where('pay_handleroute', 'pay/tokenpay')->delete();
        
        return [
            'success' => true,
            'message' => 'TokenPay 支付插件已卸载。'
        ];
        
    } catch (\Exception $e) {
        return [
            'success' => false,
            'message' => '卸载失败：' . $e->getMessage()
        ];
    }
};
