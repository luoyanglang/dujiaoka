<?php

/**
 * TokenPay 支付插件 - 安装脚本
 */

use Illuminate\Support\Facades\DB;

return function() {
    try {
        // 检查是否已存在 TokenPay 支付方式
        $exists = DB::table('pays')->where('pay_handleroute', 'pay/tokenpay')->exists();
        
        if (!$exists) {
            // 插入支付方式记录
            DB::table('pays')->insert([
                'pay_name' => 'TokenPay',
                'pay_check' => 'tokenpay',
                'pay_method' => 1, // 1=跳转, 2=扫码
                'pay_handleroute' => 'pay/tokenpay',
                'merchant_id' => '',
                'merchant_key' => '',
                'merchant_pem' => '',
                'is_open' => 0, // 默认关闭，需要用户配置后开启
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
        
        return [
            'success' => true,
            'message' => 'TokenPay 支付插件安装成功！请在支付渠道中配置相关参数。'
        ];
        
    } catch (\Exception $e) {
        return [
            'success' => false,
            'message' => '安装失败：' . $e->getMessage()
        ];
    }
};
