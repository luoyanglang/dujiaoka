# TokenPay 支付插件

支持 USDT (TRC20) 和 TRX 的加密货币支付插件。

## 功能特点

- ✅ 支持 USDT (TRC20)
- ✅ 支持 TRX
- ✅ 自动回调确认
- ✅ 安全签名验证

## 安装说明

1. 在插件市场点击"安装"
2. 安装完成后，在"支付渠道"中找到 TokenPay
3. 配置以下参数：
   - **API 地址**：你的 TokenPay 服务器地址
   - **支持币种**：选择 USDT_TRC20 或 TRX
   - **API 密钥**：TokenPay 的 API 密钥
4. 启用支付方式

## 配置示例

```
API 地址: https://your-tokenpay-api.com
支持币种: USDT_TRC20
API 密钥: your-secret-key
```

## 使用说明

配置完成后，用户在购买商品时可以选择 TokenPay 支付方式，系统会自动跳转到支付页面。

## 技术支持

- GitHub: https://github.com/LightCountry/TokenPay
- 文档: https://github.com/LightCountry/TokenPay/wiki

## 版本历史

### v1.0.0 (2025-12-08)
- 首次发布
- 支持 USDT (TRC20) 和 TRX
