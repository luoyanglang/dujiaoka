<?php

/**
 * TokenPay 支付插件 - 路由定义
 */

use Illuminate\Support\Facades\Route;
use Plugins\TokenPayPayment\TokenPayController;

// 支付网关
Route::any('/pay/tokenpay/gateway/{payway}/{orderSN}', [TokenPayController::class, 'gateway'])
    ->name('tokenpay-gateway');

// 异步通知
Route::post('/pay/tokenpay/notify_url', [TokenPayController::class, 'notifyUrl'])
    ->name('tokenpay-notify');

// 同步返回
Route::get('/pay/tokenpay/return_url', [TokenPayController::class, 'returnUrl'])
    ->name('tokenpay-return');
